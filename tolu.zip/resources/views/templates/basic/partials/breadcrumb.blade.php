
    	
			
			<!-- PAGE HERO
			============================================= -->	
			<div id="about-page" class="bg-design page-hero-section division"  style="background:#30003D; color:white;">
				<div class="container">	
					<div class="row">	
						<div class="col-lg-10 offset-lg-1">
							<div class="hero-txt text-center white-color">

								<!-- Title -->
								<h2 class="h2-sm">{{ __($pageTitle) }}</h2>
								
								<!-- Text -->	
								<p class="p-xl">Home/{{ __($pageTitle) }}</p>

							</div>
						</div>	
					</div>	  <!-- End row -->
				</div>	   <!-- End container --> 
			</div>	<!-- END PAGE HERO -->	
 