
    	
        <!-- ============================ Page Title =========================== -->
			<section class="bg-light-primary">
				<div class="container">
					<div class="row">
						<div class="col-xl-12 col-lg-12 col-12">
							<h1 class="0 text-lights"><?php echo e(__($pageTitle)); ?></h1>
						</div>
					</div>
				</div>
			</section>
			<!-- ============================ Page Title End ======================= -->
            <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/billspaypoint/core/resources/views/templates/basic/partials/breadcrumb.blade.php ENDPATH**/ ?>