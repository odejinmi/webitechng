
    	
			
			<!-- PAGE HERO
			============================================= -->	
			<div id="about-page" class="bg-design page-hero-section division">
				<div class="container">	
					<div class="row">	
						<div class="col-lg-10 offset-lg-1">
							<div class="hero-txt text-center white-color">

								<!-- Title -->
								<h2 class="h2-sm"><?php echo e(__($pageTitle)); ?></h2>
								
								<!-- Text -->	
								<p class="p-xl">Home/<?php echo e(__($pageTitle)); ?></p>

							</div>
						</div>	
					</div>	  <!-- End row -->
				</div>	   <!-- End container --> 
			</div>	<!-- END PAGE HERO -->	
 <?php /**PATH /home/ltecyxtc/public_html/core/resources/views/templates/basic/partials/breadcrumb.blade.php ENDPATH**/ ?>