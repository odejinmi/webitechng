<?php echo  loadExtension('tawk-chat') ?>
<?php echo  loadExtension('google-analytics') ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/itechng/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>